package com.example.jnubus_19_06_02;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.BottomNavigationView;
import android.support.v7.app.AppCompatActivity;
import android.support.annotation.NonNull;
import android.view.MenuItem;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;


public class MainActivity extends AppCompatActivity {
    Timer timer = null;
    TimerTask timerTask = null;

    private TextView mTextMessage;
    private ImageView imageView1;
    private ImageView bus;
    private ImageButton aline;
    private ImageButton bline;
    private RelativeLayout line_back;

    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            switch (item.getItemId()) {
                case R.id.navigation_routemap:
                    line_back.setVisibility(View.VISIBLE);
                    bus.setVisibility(View.VISIBLE);
                    imageView1.setVisibility(View.VISIBLE);
                    return true;
                case R.id.navigation_timetable:
                    line_back.setVisibility(View.INVISIBLE);
                    bus.setVisibility(View.INVISIBLE);
                    imageView1.setVisibility(View.INVISIBLE);
                    return true;
                case R.id.navigation_nearbusstop:
                    bus.setVisibility(View.INVISIBLE);
                    line_back.setVisibility(View.INVISIBLE);
                    imageView1.setVisibility(View.INVISIBLE);
                    return true;
                case R.id.navigation_setting:
                    line_back.setVisibility(View.INVISIBLE);
                    bus.setVisibility(View.INVISIBLE);
                    imageView1.setVisibility(View.INVISIBLE);
                    return true;
            }
            return false;
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        startTimerThread();//타이머 시작

        BottomNavigationView navView = findViewById(R.id.nav_view);
        imageView1 = findViewById(R.id.imageView);
        bus = (ImageView)findViewById(R.id.bus);
        line_back = findViewById(R.id.line_back);
        navView.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);


           aline = (ImageButton) findViewById(R.id.aline) ;
           bline = (ImageButton) findViewById(R.id.bline_not) ;

            //기본값
            aline.setImageResource(R.drawable.aline);
            aline.setTag(R.drawable.aline);
            bline.setImageResource(R.drawable.bline_not);
            bline.setTag(R.drawable.bline_not);


            aline.setOnClickListener(new Button.OnClickListener() {
                @Override
                public void onClick(View view) {
                    aline.setImageResource(R.drawable.aline);
                    aline.setTag(R.drawable.aline);
                    bline.setImageResource(R.drawable.bline_not);
                    bline.setTag(R.drawable.bline_not);
                }
            }) ;

            bline.setOnClickListener(new Button.OnClickListener() {
                @Override
                public void onClick(View view) {
                    bline.setImageResource(R.drawable.bline);
                    bline.setTag(R.drawable.bline);
                    aline.setImageResource(R.drawable.aline_not);
                    aline.setTag(R.drawable.aline_not);
                }
            }) ;

    }

    public void startTimerThread(){
        timerTask = new TimerTask(){ //timerTask는 timer가 일할 내용을 기록하는 객체
            @Override
            public void run() {
                // TODO Auto-generated method stub
                //이곳에 timer가 동작할 task를 작성

                move_A();
//                if(aline.getTag().equals(R.drawable.aline)){
//
//                }
//                if(aline.getTag().equals(R.drawable.aline_not)){
//                    move_B();
//                }
            }

        };
        timer= new Timer(); //timer생성
        timer.schedule(timerTask, 0,600000); //timerTask라는 일을 갖는 timer를 0초딜레이로 1000ms마다 실행
    }

    public void move_A(){
        Animation anim = AnimationUtils
                .loadAnimation
                        (getApplicationContext(),
                                R.anim.seta_anim);
        bus.startAnimation(anim);
    }
    public void move_B(){
        Animation anim = AnimationUtils
                .loadAnimation
                        (getApplicationContext(),
                                R.anim.setb_anim);
        bus.startAnimation(anim);

    }

//    public void registerAlarm()
//    {
////        Log.e("###", "registerAlarm");
//        Intent intent = new Intent(this, AlarmService_Service.class);
//        PendingIntent sender = PendingIntent.getBroadcast(this, 0, intent, 0);
//
//        try
//        {
//            // 내일 아침 8시 10분에 처음 시작해서, 24시간 마다 실행되게
//            Date tomorrow = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss").parse("2012-02-25 08:10:00");
//            AlarmManager am = (AlarmManager) getSystemService(ALARM_SERVICE);
//            am.setInexactRepeating(AlarmManager.RTC, tomorrow.getTime(), 24 * 60 * 60 * 1000, sender);
//        } catch (ParseException e)
//        {
//            e.printStackTrace();
//        }
//    }

}
